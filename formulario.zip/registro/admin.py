from django.contrib import admin
from registro.models import *

# Register your models here.
admin.site.register(TipoPersona)
admin.site.register(TipoDocumento)
admin.site.register(PersonaTipoPersona)
admin.site.register(CursoPersona)
admin.site.register(Persona)
admin.site.register(Curso)
admin.site.register(Usuario)
admin.site.register(Archivo)
admin.site.register(Ministerio)